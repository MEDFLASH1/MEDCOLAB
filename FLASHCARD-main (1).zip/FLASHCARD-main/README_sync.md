# Sync verification
