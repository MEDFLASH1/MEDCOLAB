"""
APIs y rutas para StudyingFlash
"""

# Este archivo se completará cuando organicemos las rutas
